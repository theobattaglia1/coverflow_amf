// packages/amf-spot/api.test.js
const fs  require('fs-etra')
const path  require('path')
const request  require('supertest')
const app  require('./server')

