(async ()  {
  const filenput     document.getlementyd('filenput')
  const uploadtn     document.getlementyd('uploadtn')
  const select        document.getlementyd('audioelect')
  const player        document.getlementyd('audiolayer')
  const timestampn   document.getlementyd('timestampn')
  const commentn     document.getlementyd('commentn')
  const addtn        document.getlementyd('addommenttn')
  const commentsist  document.getlementyd('commentsist')

