// calendar.js
document.addEventListener('DOMContentLoaded', function() {
  var signInBtn = document.getElementById('sign-in-btn');
  var eventsContainer = document.getElementById('events-container');

  var hasToken = document.cookie
    .split(';')
    .some(function(c) { return c.trim().indexOf('google_tokens=') === 0; });

  if (hasToken) {
    signInBtn.style.display = 'none';
    console.info(new Date().toISOString() + ' - Google tokens found; hiding sign-in');
  } else {
    console.info(new Date().toISOString() + ' - No tokens; sign-in visible');
  }

  // build absolute URL to avoid credentials in base URL
  var eventsUrl = window.location.origin + '/api/calendar-events';
  console.info(new Date().toISOString() + ' - Fetching ' + eventsUrl);

  fetch(eventsUrl, { credentials: 'include' })
    .then(function(res) {
      console.info(new Date().toISOString() + ' - status ' + res.status);
      return res.json();
    })
    .then(function(events) {
      console.info(new Date().toISOString() + ' - loaded ' + events.length + ' events');
      renderCalendarGrid(events);
    })
    .catch(function(err) {
      console.error(new Date().toISOString() + ' - error fetching events', err);
      eventsContainer.textContent = 'Failed to load events.';
    });
});

function renderCalendarGrid(events) {
  var container = document.getElementById('events-container');
  container.innerHTML = '';
  events.forEach(function(evt) {
    var raw = (evt.start && (evt.start.dateTime || evt.start.date)) || null;
    var start = raw ? new Date(raw) : null;

    var dateStr = start ? start.toLocaleDateString() : 'Invalid Date';
    var timeStr = start && evt.start.dateTime ? start.toLocaleTimeString() : '';

    var card = document.createElement('div');
    card.className = 'event-card';
    card.innerHTML =
      '<div class="event-date">' + dateStr + '</div>' +
      '<div class="event-time">' + timeStr + '</div>' +
      '<div class="event-title">' + (evt.summary || 'No title') + '</div>';
    container.appendChild(card);
  });
}
