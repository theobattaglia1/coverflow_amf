(async () => {
  const fileInput    = document.getElementById('fileInput');
  const uploadBtn    = document.getElementById('uploadBtn');
  const select       = document.getElementById('audioSelect');
  const player       = document.getElementById('audioPlayer');
  const timestampIn  = document.getElementById('timestampIn');
  const commentIn    = document.getElementById('commentIn');
  const addBtn       = document.getElementById('addCommentBtn');
  const commentsList = document.getElementById('commentsList');

