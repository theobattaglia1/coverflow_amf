#!/usr/bin/env bash
set -e

echo "→ Cleaning JS files in $(pwd)"

# Force C locale for sed
export LC_ALL=C

# 1. Remove UTF-8 BOM
find . -type f -name '*.js' -exec perl -i -pe 's/^\x{FEFF}//;' {} +

# 2. Replace curly quotes with straight quotes
find . -type f -name '*.js' \
  -exec perl -i -pe 's/[“”]/"/g; s/[‘’]/'\''/g;' {} +

# 3. Remove leftover patch markers (---, +++, @@)
find . -type f -name '*.js' \
  -exec sed -i '' \
    -e '/^--- /d' \
    -e '/^\+\+\+ /d' \
    -e '/^@@ /d' {} \;

echo "✓ Cleanup complete"
