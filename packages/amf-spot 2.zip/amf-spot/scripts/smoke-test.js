#!/usr/bin/env node

// Smoke‐test script for AMF Spot
// Run with: node scripts/smoke-test.js

var axios = require('axios');
var FormData = require('form-data');
var fs = require('fs');
var path = require('path');

// Local server base URL
var baseURL = 'http://localhost:3000';
var client = axios.create({ baseURL: baseURL, timeout: 5000 });

function logStep(name, fn) {
  process.stdout.write('[' + new Date().toISOString() + '] ' + name + '... ');
  return fn()
    .then(function() { console.log('OK'); })
    .catch(function(err) {
      console.log('FAIL');
      console.error(err.message || err);
      process.exit(1);
    });
}

function run() {
  // 1. Health check
  logStep('GET /ping', function() {
    return client.get('/ping').then(function(res) {
      if (res.status !== 200) throw new Error('Status ' + res.status);
    });
  })
  // 2. Comments CRUD
  .then(function() {
    return logStep('GET /api/comments', function() {
      return client.get('/api/comments').then(function(res) {
        if (res.status !== 200) throw new Error('Status ' + res.status);
      });
    });
  })
  .then(function() {
    return logStep('POST /api/comments', function() {
      return client.post('/api/comments', { text: 'Smoke test comment' })
        .then(function(res) {
          if ([200,201].indexOf(res.status) < 0) throw new Error('Status ' + res.status);
        });
    });
  })
  // 3. Captions CRUD
  .then(function() {
    return logStep('GET /api/captions', function() {
      return client.get('/api/captions').then(function(res) {
        if (res.status !== 200) throw new Error('Status ' + res.status);
      });
    });
  })
  .then(function() {
    return logStep('POST /api/captions', function() {
      return client.post('/api/captions', { file: 'smoke.jpg', caption: 'Smoke caption' })
        .then(function(res) {
          if ([200,201].indexOf(res.status) < 0) throw new Error('Status ' + res.status);
        });
    });
  })
  // 4. Tasks CRUD
  .then(function() {
    return logStep('GET /api/tasks', function() {
      return client.get('/api/tasks').then(function(res) {
        if (res.status !== 200) throw new Error('Status ' + res.status);
      });
    });
  })
  .then(function() {
    return logStep('POST /api/tasks', function() {
      return client.post('/api/tasks', { title: 'Smoke test task', date: new Date().toISOString() })
        .then(function(res) {
          if ([200,201].indexOf(res.status) < 0) throw new Error('Status ' + res.status);
          run.taskId = res.data.id || res.data._id;
        });
    });
  })
  .then(function() {
    return logStep('DELETE /api/tasks/:id', function() {
      return client.delete('/api/tasks/' + run.taskId).then(function(res) {
        if ([200,204].indexOf(res.status) < 0) throw new Error('Status ' + res.status);
      });
    });
  })
  // 5. Calendar events
  .then(function() {
    return logStep('GET /api/calendar-events', function() {
      return client.get('/api/calendar-events').then(function(res) {
        if (res.status !== 200) throw new Error('Status ' + res.status);
      });
    });
  })
  .then(function() {
    console.log('\n✓ All smoke tests passed');
  });
}

run();
