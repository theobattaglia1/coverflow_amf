require('dotenv').config();
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var basicAuth = require('express-basic-auth');
var logger = require('./utils/logger');
var { google } = require('googleapis');

var app = express();
var PORT = process.env.PORT || 3000;

// Log every request
app.use(function(req, res, next) {
  logger.info(req.method + ' ' + req.url);
  next();
});

// Parsers

/** Protect API & OAuth */
var protect = basicAuth({
  users: (function(){var u={};u[process.env.ADMIN_USERNAME]=process.env.ADMIN_PASSWORD;return u;})(),
  challenge:true,
  unauthorizedResponse: function(){return 'Auth required';}
});
app.use('/api', protect);
app.use('/auth/google', protect);
app.use('/oauth2callback', protect);

// & cookies
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

// Basic‑Auth on /admin
app.use(
  ['/admin', '/admin/*'],
  basicAuth({
    users: (function(){
      var u = {};
      u[process.env.ADMIN_USERNAME] = process.env.ADMIN_PASSWORD;
      return u;
    })(),
    challenge: true,
    unauthorizedResponse: function(req) {
      logger.error('Unauthorized attempt to ' + req.url);
      return 'Authentication required';
    }
  })
);

// Static folders
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/admin', express.static(path.join(__dirname, 'public', 'admin')));

// Health check
app.get('/ping', function(req, res) {
  logger.info('GET /ping -> 200');
  res.send('pong');
});

// Comments API
app.get('/api/comments', function(req, res) {
  logger.info('GET /api/comments');
  res.json([]);
});
app.post('/api/comments', function(req, res) {
  logger.info('POST /api/comments');
  res.status(201).json(req.body);
});

// Captions API
app.get('/api/captions', function(req, res) {
  logger.info('GET /api/captions');
  res.json([]);
});
app.post('/api/captions', function(req, res) {
  logger.info('POST /api/captions');
  res.status(201).json(req.body);
});

// Tasks API
app.get('/api/tasks', function(req, res) {
  logger.info('GET /api/tasks');
  res.json([]);
});
app.post('/api/tasks', function(req, res) {
  logger.info('POST /api/tasks');
  res.status(201).json(req.body);
});
app.delete('/api/tasks/:id', function(req, res) {
  logger.info('DELETE /api/tasks/' + req.params.id);
  res.status(204).send();
});

// --- Google OAuth2 & Calendar ---
var oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);
var SCOPES = ['https://www.googleapis.com/auth/calendar.readonly'];

// 1) Redirect to Google for consent
app.get('/auth/google', function(req, res) {
  logger.info('GET /auth/google');
  var url = oauth2Client.generateAuthUrl({ access_type: 'offline', scope: SCOPES });
  res.redirect(url);
});

// 2) Google redirects back here with code
app.get('/oauth2callback', async function(req, res) {
  logger.info('GET /oauth2callback');
  try {
    var code = req.query.code;
    var { tokens } = await oauth2Client.getToken(code);
    res.cookie('google_tokens', JSON.stringify(tokens), { httpOnly: true });
    res.redirect('/admin/calendar');
  } catch (err) {
    logger.error('OAuth callback error - ' + err);
    res.status(500).send('Authentication error');
  }
});

// 3) Serve real calendar events
app.get('/api/calendar-events', async function(req, res) {
  logger.info('GET /api/calendar-events');
  try {
    var raw = req.cookies.google_tokens;
    if (!raw) return res.status(401).json({ error: 'Not authenticated' });
    var tokens = JSON.parse(raw);
    oauth2Client.setCredentials(tokens);
    var cal = google.calendar({ version: 'v3', auth: oauth2Client });
    var resp = await cal.events.list({
      calendarId: 'primary',
      timeMin: (new Date()).toISOString(),
      maxResults: 10,
      singleEvents: true,
      orderBy: 'startTime'
    });
    res.json(resp.data.items);
  } catch (err) {
    logger.error('Error fetching calendar events - ' + err);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

// SPA fallback for /admin/*
app.get('/admin/*', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html'));
});

// 404 & error handlers
app.use(function(req, res) {
  logger.info('404 ' + req.method + ' ' + req.url);
  res.status(404).send('Not found');
});
app.use(function(err, req, res, next) {
  logger.error('ERROR ' + req.method + ' ' + req.url + ' - ' + err.stack);
  res.status(500).send('Server error');
});

// Start
app.listen(PORT, function() {
  logger.info('Server listening on port ' + PORT);
});
