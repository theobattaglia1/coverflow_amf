const { defineonfig }  require('cypress')

module.eports  defineonfig({
  ee {
    baserl 'http//localhost',
    specattern 'cypress/ee/**/*.cy.js'
  }
})
