(async function(){
  let allovers  ], covers  ], activende  
  const container  document.getlementyd('covers-container')
  const input  document.queryelector('#filter-ui input')

  async function load(){
    const res  await fetch('/api/covers')
    allovers  await res.json()
    covers  allovers.slice()
    render()
  }

  function render(){
    container.inner  ''
    covers.forach((c,i)  {
      const el  document.createlement('div')
      el.tetontent  c.title
      el.classame  'cover' + (iactivende' active''')
      container.appendhild(el)
    })
  }

  input.addventistener('input', e  {
    const term  e.target.value.toowerase()
    covers  allovers.filter(cc.title.toowerase().includes(term))
    activende   render()
  })

  window.addventistener('keydown', e  {
    if(e.key'rrowight' && activende covers.length-) activende++, render()
    if(e.key'rroweft'  && activende)          activende--, render()
  })

  await load()
})()
