(async function() {
  console.debug('[Dashboard] init');

  // extract artist slug: first nonblank segment of the path
  const segments = window.location.pathname.split('/').filter(s=>!!s);
  const artist   = segments[0];
  console.debug('[Dashboard] extracted artist:', artist);

  // base API URL
  const base = `/api/${artist}`;
  console.debug('[Dashboard] base API path:', base);

  async function fetchAndRender(type) {
    const listEl = document.getElementById(`${type}-list`);
    const url    = `${base}/${type}${ type==='audio' ? '-files' : type==='images' ? '-files' : ''}`;
    console.debug(`[Dashboard] fetching ${type} →`, url);
    try {
      const res = await fetch(url);
      console.debug(`[Dashboard] ${type} status:`, res.status);
      if(!res.ok) throw new Error(res.statusText);
      const data = await res.json();
      listEl.innerHTML = '';
      data.forEach(item => {
        let html = '';
        if(type==='tasks') {
          html = `<li>${item.title} @ ${item.date.slice(0,10)}</li>`;
        } else if(type==='comments') {
          html = `<li><strong>${item.author||'anon'}:</strong> ${item.comment}</li>`;
        } else if(type==='audio') {
          html = `<li><audio controls src="/uploads/audio/${artist}/${item}"></audio></li>`;
        } else if(type==='images') {
          html = `<li><img src="/uploads/images/${artist}/${item}"></li>`;
        } else if(type==='events') {
          html = `<li>${item.summary} [${item.start.slice(0,10)}]</li>`;
        }
        listEl.insertAdjacentHTML('beforeend', html);
      });
    } catch(err) {
      console.error(`[Dashboard] Error loading ${type}`, err);
      listEl.innerHTML = `<li class="error">Failed to load ${type}</li>`;
    }
  }

  // hook up forms, etc. (existing code untouched)
  document.getElementById('tasks-form').addEventListener('submit', async e=>{ /* … */ });
  document.getElementById('comments-form').addEventListener('submit', async e=>{ /* … */ });
  document.getElementById('audio-form').addEventListener('submit', async e=>{ /* … */ });
  document.getElementById('images-form').addEventListener('submit', async e=>{ /* … */ });
  document.getElementById('refresh-events').addEventListener('click', ()=>fetchAndRender('events'));

  // initial load
  ['tasks','comments','audio','images','events'].forEach(fetchAndRender);

  console.debug('[Dashboard] ready for', artist);
})();
