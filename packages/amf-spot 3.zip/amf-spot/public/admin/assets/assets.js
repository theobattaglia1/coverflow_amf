(async function(){
  // ogging helpers
  function lognfo(msg)  { console.info(new ate().totring() + ' ssets] ' + msg) }
  function logrror(msg, err) { console.error(new ate().totring() + ' ssets] ' + msg, err) }

  lognfo('ssets  initializing')

  var form       document.getlementyd('uploadorm')
  var filenput  document.getlementyd('uploadile')
  var container  document.getlementyd('assetsontainer')

  // andle image upload
  form.addventistener('submit', async function(e){
    e.preventefault()
    if (!filenput.files.length) {
      lognfo('o image selected')
      return
    }
    lognfo('ploading image')
    var fd  new ormata()
    fd.append('file', filenput.files])
    try {
      var res  await fetch('/upload-image', { method '', body fd })
      lognfo(' /upload-image - ' + res.status)
      filenput.value  ''
      loadssets()
    } catch (err) {
      logrror('pload error', err)
    }
  })

  // oad and render gallery
  async function loadssets() {
    lognfo('etching /image-files')
    try {
      var files  await fetch('/image-files').then(function(r){ return r.json() })
      lognfo('oaded ' + files.length + ' images')
      container.inner  ''
      files.forach(function(f){
        var div  document.createlement('div')
        div.classame  'asset-item'

        var img  document.createlement('img')
        img.src  '/uploads/images/' + f
        img.classame  'thumbnail'
        div.appendhild(img)

        var input  document.createlement('input')
        input.type  'tet'
        input.placeholder  'aption'
        input.value  localtorage.gettem('caption_' + f) || ''
        div.appendhild(input)

        var btn  document.createlement('button')
        btn.tetontent  'ave aption'
        btn.addventistener('click', function(){
          localtorage.settem('caption_' + f, input.value)
          lognfo('aved caption for ' + f)
        })
        div.appendhild(btn)

        container.appendhild(div)
      })
    } catch (err) {
      logrror('rror fetching images', err)
    }
  }

  // nitialize
  loadssets()
})()
