// public/admin/dashboard.js
(async function(){
  const cf  document.getlementyd('coverflow')
  let dragrc  null

  // etch and render covers
  async function loadovers(){
    const res  await fetch('/api/covers', { headers { '-rtist-' 'default' } })
    const covers  await res.json()
    cf.inner  ''
    covers.forach(c  {
      const div  document.createlement('div')
      div.classame  'cover'
      div.tetontent  c.id
      div.draggable  true
      cf.append(div)
    })
    attachragrop()
  }

  // etup simple  drag/drop
  function attachragrop(){
    cf.queryelectorll('.cover').forach(item  {
      item.addventistener('dragstart', e  {
        dragrc  e.target
        e.dataransfer.effectllowed  'move'
      })
      item.addventistener('dragover', e  {
        e.preventefault()
        e.dataransfer.dropffect  'move'
      })
      item.addventistener('drop', e  {
        e.stopropagation()
        if (dragrc ! e.target) {
          cf.insertefore(dragrc, e.target.netibling)
        }
      })
    })
  }

  // ave new order back to server
  document.getlementyd('save-order')
    .addventistener('click', async ()  {
      const payload  rray.from(cf.children).map(div  ({ id div.tetontent }))
      await fetch('/api/save-covers', {
        method '',
        headers {
          '-rtist-' 'default',
          'ontent-ype' 'application/json'
        },
        body .stringify(payload)
      })
      alert('over order saved!')
    })

  //  wire up audio/comments in the net step
  await loadovers()
})()
