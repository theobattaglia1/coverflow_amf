(async function() {
  console.log('[Calendar] IIFE start');
  
  const signInBtn = document.getElementById('sign-in-btn');
  const eventsContainer = document.getElementById('events-container');
  console.log('[Calendar] DOM nodes:', { signInBtn, eventsContainer });
  
  // wire up your sign‑in button
  signInBtn.addEventListener('click', () => {
    console.log('[Calendar] Sign‑in clicked, redirecting to /auth/google');
    window.location.href = '/auth/google';
  });
  
  // fetch and render events
  async function loadEvents() {
    eventsContainer.textContent = 'Loading events…';
    try {
      const resp = await fetch('/api/calendar-events');
      console.log('[Calendar] /api/calendar-events status:', resp.status);
      
      if (resp.status === 401) {
        console.warn('[Calendar] Unauthorized → showing sign‑in');
        signInBtn.style.display = 'block';
        eventsContainer.textContent = '';
        return;
      }
      
      if (!resp.ok) {
        console.error('[Calendar] Fetch error:', resp.status, resp.statusText);
        eventsContainer.textContent = 'Error loading events';
        return;
      }
      
      const events = await resp.json();
      console.log('[Calendar] Fetched events:', events);
      
      signInBtn.style.display = 'none';
      eventsContainer.innerHTML = '';
      
      if (!events.length) {
        eventsContainer.textContent = 'No upcoming events';
        return;
      }
      
      events.forEach(ev => {
        const card = document.createElement('div');
        card.className = 'event-card';
        
        const date = document.createElement('div');
        date.className = 'event-date';
        date.textContent = new Date(ev.start).toLocaleString();
        
        const title = document.createElement('div');
        title.className = 'event-title';
        title.textContent = ev.summary || '(no title)';
        
        card.append(date, title);
        eventsContainer.append(card);
      });
      
    } catch (err) {
      console.error('[Calendar] Exception fetching events:', err);
      eventsContainer.textContent = 'Failed to load events';
    }
  }
  
  await loadEvents();
  console.log('[Calendar] Render complete');
})();
