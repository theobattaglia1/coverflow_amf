(async function(){
  'use strict';
  console.debug('[Dashboard] init');

  // figure out which artist we’re on
  const parts  = location.pathname.split('/').filter(Boolean);
  const artist = parts[1];
  const base   = '/api/' + artist;

  const endpoints = {
    tasks:    base + '/tasks',
    comments: base + '/comments',
    audio:    base + '/audio-files',
    images:   base + '/image-files',
    events:   base + '/calendar-events'
  };

  async function fetchAndRender(key){
    const list = document.getElementById(key + '-list');
    try {
      console.debug('[Dashboard] fetching', key, '→', endpoints[key]);
      const res = await fetch(endpoints[key]);
      console.debug('[Dashboard]', key, 'status:', res.status);
      if (!res.ok) throw new Error(res.statusText || res.status);
      const data = await res.json();

      // clear “Loading…” or previous
      list.innerHTML = '';

      data.forEach(item => {
        const li = document.createElement('li');

        switch(key){
          case 'tasks':
            li.textContent = item.title + ' @ ' + item.date;
            break;

          case 'comments':
            li.textContent = item.author + ': ' + item.text;
            break;

          case 'audio':
            // real <audio> player, pointing at the artist subfolder
            const audio = document.createElement('audio');
            audio.controls = true;
            audio.src = `/uploads/audio/${artist}/${encodeURIComponent(item)}`;
            li.appendChild(audio);
            break;

          case 'images':
            // thumbnail <img> pointing at the artist subfolder
            const img = document.createElement('img');
            img.src = `/uploads/images/${artist}/${encodeURIComponent(item)}`;
            img.style.maxWidth = '150px';
            li.appendChild(img);
            break;

          case 'events':
            li.textContent = item.summary + ' @ ' + item.start;
            break;

          default:
            li.textContent = JSON.stringify(item);
        }

        list.appendChild(li);
      });

    } catch(err) {
      console.error('[Dashboard] Error loading', key, err);
      list.innerHTML = '<li style="color:red"><strong>Failed to load</strong></li>';
    }
  }

  // wire up the forms (unchanged)
  document.getElementById('tasks-form').addEventListener('submit', async e=>{
    e.preventDefault();
    const title = document.getElementById('task-title').value;
    const date  = document.getElementById('task-date').value;
    await fetch(endpoints.tasks, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({title,date})
    });
    e.target.reset();
    fetchAndRender('tasks');
  });

  document.getElementById('comments-form').addEventListener('submit', async e=>{
    e.preventDefault();
    const author = document.getElementById('comment-author').value;
    const text   = document.getElementById('comment-text').value;
    await fetch(endpoints.comments, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({author,text})
    });
    e.target.reset();
    fetchAndRender('comments');
  });

  document.getElementById('audio-form').addEventListener('submit', async e=>{
    e.preventDefault();
    const file = document.getElementById('audio-file').files[0];
    const fm   = new FormData();
    fm.append('file', file);
    await fetch(`/api/${artist}/upload-audio`, { method:'POST', body:fm });
    e.target.reset();
    fetchAndRender('audio');
  });

  document.getElementById('images-form').addEventListener('submit', async e=>{
    e.preventDefault();
    const file = document.getElementById('image-file').files[0];
    const fm   = new FormData();
    fm.append('file', file);
    await fetch(`/api/${artist}/upload-image`, { method:'POST', body:fm });
    e.target.reset();
    fetchAndRender('images');
  });

  document.getElementById('refresh-events')
    .addEventListener('click', ()=> fetchAndRender('events'));

  // initial load
  ['tasks','comments','audio','images','events']
    .forEach(fetchAndRender);

  console.debug('[Dashboard] ready for', artist);
})();
