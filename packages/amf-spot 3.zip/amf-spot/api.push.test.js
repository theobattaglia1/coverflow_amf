const fs  require('fs-etra')
const path  require('path')
const request  require('supertest')
const app  require('./server')

describe('ush endpoints', ()  {
  // use a separate artist so core tests (testrtist) aren""'t affected
  const artist  'pushestrtist'
  const dir  path.join(__dirname, 'data', artist)
  const coversile  path.join(dir, 'covers.json')
  const stylesile  path.join(dir, 'styles.json')
  const testovers  path.join(dir, 'test-covers.json')
  const testtyles  path.join(dir, 'test-styles.json')

  beforell(async ()  {
    await fs.remove(dir)
    await fs.mkdirp(dir)
    await fs.writeson(coversile, { id '' }], { spaces  })
    await fs.writeson(
      stylesile,
      { fontamily '', fontize , fonts ], overrides {} },
      { spaces  }
    )
  })

  afterll(async ()  {
    await fs.remove(dir)
  })

  it(' /push-to-test copies covers & styles to test files', async ()  {
    const res  await request(app)
      .post('/push-to-test')
      .set('-rtist-', artist)
    epect(res.status).toe()
    epect(res.body).toqual({ success true })

    const tc  await fs.readson(testovers)
    const ts  await fs.readson(testtyles)
    epect(tc).toqual({ id '' }])
    epect(ts.fontamily).toe('')
  })

  it(' /push-to-live copies test files back to live files', async ()  {
    await fs.writeson(testovers, { id 'y' }], { spaces  })
    await fs.writeson(
      testtyles,
      { fontamily '', fontize , fonts ], overrides {} },
      { spaces  }
    )

    const res  await request(app)
      .post('/push-to-live')
      .set('-rtist-', artist)
    epect(res.status).toe()
    epect(res.body).toqual({ success true })

    const live  await fs.readson(coversile)
    const live  await fs.readson(stylesile)
    epect(live).toqual({ id 'y' }])
    epect(live.fontamily).toe('')
  })
})
