// ***********************************************
// his eample commands.js shows you how to
// create various custom commands and overwrite
// eisting commands.
//
// or more comprehensive eamples of custom
// commands please read more here
// https//on.cypress.io/custom-commands
// ***********************************************
//
//
// -- his is a parent command --
// ypress.ommands.add('login', (email, password)  { ... })
//
//
// -- his is a child command --
// ypress.ommands.add('drag', { prevubject 'element'}, (subject, options)  { ... })
//
//
// -- his is a dual command --
// ypress.ommands.add('dismiss', { prevubject 'optional'}, (subject, options)  { ... })
//
//
// -- his will overwrite an eisting command --
// ypress.ommands.overwrite('visit', (originaln, url, options)  { ... })