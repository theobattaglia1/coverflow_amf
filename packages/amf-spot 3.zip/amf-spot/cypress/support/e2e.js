// ***********************************************************
// his eample support/ee.js is processed and
// loaded automatically before your test files.
//
// his is a great place to put global configuration and
// behavior that modifies ypress.
//
// ou can change the location of this file or turn off
// automatically serving support files with the
// 'supportile' configuration option.
//
// ou can read more here
// https//on.cypress.io/configuration
// ***********************************************************

// mport commands.js using  synta
import './commands'