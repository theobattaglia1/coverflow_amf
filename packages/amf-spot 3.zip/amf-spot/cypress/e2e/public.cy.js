describe('ublic ', ()  {
  before(()  {
    cy.visit('/')
    cy.wait()
  })

  it('displays cover elements', ()  {
    cy.get('.cover', { timeout  }).should('eist')
  })

  it.skip('changes active cover with rrowight', ()  {
    cy.get('.cover.active', { timeout  }).should('eist').then($a  {
      cy.get('body').type('{rightarrow}')
      cy.get('.cover.active', { timeout  }).should($a  {
        epect($a]).not.to.equal($a])
      })
    })
  })

  it.skip('filter input narrows results', ()  {
    cy.get('input', { timeout  }).should('eist').clear().type('nope')
    cy.get('.cover', { timeout  }).should('have.length', )
  })
})
