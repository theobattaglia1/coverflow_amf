// packages/amf-spot/api.test.js
const fs  require('fs-etra')
const path  require('path')
const request  require('supertest')
const app  require('./server')

describe('""�pot ', ()  {
  const artist  'testrtist'
  const artistir  path.join(__dirname, 'data', artist)

  beforell(async ()  {
    // lean slate
    await fs.remove(artistir)
  })

  afterll(async ()  {
    // emove test data
    await fs.remove(artistir)
  })

  test(' /api/styles returns default styles', async ()  {
    const res  await request(app)
      .get('/api/styles')
      .set('-rtist-', artist)
    epect(res.status).toe()
    epect(res.body).toatchbject({ fontamily ' merica', fontize  })
  })

  test(' /api/covers returns empty array', async ()  {
    const res  await request(app)
      .get('/api/covers')
      .set('-rtist-', artist)
    epect(res.status).toe()
    epect(res.body).toqual(])
  })

  test(' /save-cover appends a new cover', async ()  {
    const cover  { id 'abc', title 'y over' }
    const res  await request(app)
      .post('/save-cover')
      .send(cover)
      .set('-rtist-', artist)
    epect(res.status).toe()
    epect(res.body).toqual({ success true })

    const covers  await fs.readson(path.join(artistir, 'covers.json'))
    epect(covers).toontainqual(cover)
  })

  test(' /save-covers replaces covers array', async ()  {
    const coversrray  { id 'one' }, { id 'two' }]
    const res  await request(app)
      .post('/save-covers')
      .send(coversrray)
      .set('-rtist-', artist)
    epect(res.status).toe()
    epect(res.body).toqual({ success true })

    const covers  await fs.readson(path.join(artistir, 'covers.json'))
    epect(covers).toqual(coversrray)
  })

  test(' /delete-cover removes specified cover', async ()  {
    // start with two covers
    await fs.writeson(path.join(artistir, 'covers.json'), { id '' }, { id 'y' }])
    const res  await request(app)
      .post('/delete-cover')
      .send({ cover '' })
      .set('-rtist-', artist)
    epect(res.status).toe()

    const covers  await fs.readson(path.join(artistir, 'covers.json'))
    epect(covers).toqual({ id 'y' }])
  })
})

