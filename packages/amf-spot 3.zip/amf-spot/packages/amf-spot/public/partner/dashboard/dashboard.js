/*  ─────────────────────────────────────────────────────────
    PARTNER DASHBOARD SCRIPT   (updated 2025‑04‑21 23:45 UTC)
    – read‑only except comments
    – detects artist slug automatically
    – extensive debug logging
    ───────────────────────────────────────────────────────── */
(() => {
  function getArtist () {
    const p = location.pathname.split('/').filter(Boolean);
    console.debug('[Dashboard‑partner] raw path parts:', p);
    return p[0] === 'admin' ? p[1] : p[0];
  }

  const artist = getArtist();
  const base   = `/api/${artist}`;
  console.debug('[Dashboard‑partner] artist =', artist);
  console.debug('[Dashboard‑partner] base API path =', base);

  const ep = {
    tasks   : `${base}/tasks`,
    comments: `${base}/comments`,
    audio   : `${base}/audio-files`,
    images  : `${base}/image-files`,
    events  : `${base}/calendar-events`
  };

  async function fetchAndRender (key) {
    const url = ep[key];
    const list= document.getElementById(`${key}-list`);
    console.debug(`[Dashboard‑partner] fetching ${key} →`, url);

    try {
      const r = await fetch(url);
      console.debug(`[Dashboard‑partner] ${key} status`, r.status);
      if (!r.ok) throw new Error(r.statusText||r.status);
      const data = await r.json();
      list.innerHTML='';
      data.forEach(item=>{
        switch(key){
          case 'tasks'   : list.insertAdjacentHTML('beforeend',`<li>${item.title}</li>`); break;
          case 'comments': list.insertAdjacentHTML('beforeend',`<li><b>${item.author||'anon'}:</b> ${item.text}</li>`); break;
          case 'audio'   : list.insertAdjacentHTML('beforeend',`<li><audio controls src="/uploads/audio/${item}"></audio></li>`); break;
          case 'images'  : list.insertAdjacentHTML('beforeend',`<li><img src="/uploads/images/${item}" alt=""></li>`); break;
          case 'events'  : list.insertAdjacentHTML('beforeend',`<li>${item.summary}</li>`); break;
        }
      });
    } catch(err){
      console.error(`[Dashboard‑partner] Error loading ${key}`, err);
      list.innerHTML = '<li style="color:#c00"><strong>Failed to load</strong></li>';
    }
  }

  /* ---------- kick off ---------- */
  ['tasks','comments','audio','images','events'].forEach(fetchAndRender);
  console.debug('[Dashboard‑partner] ready ✅');
})();
