/*  ─────────────────────────────────────────────────────────
    ADMIN DASHBOARD SCRIPT   (updated 2025‑04‑21 23:45 UTC)
    – detects correct artist slug from any path
    – hits /api/<artist>/… endpoints
    – extensive debug logging
    ───────────────────────────────────────────────────────── */
(() => {
  /* ---------- slug helper ---------- */
  function getArtistFromPath () {
    const parts = location.pathname.split('/').filter(Boolean);
    console.debug('[Dashboard‑admin] raw path parts:', parts);
    // possible shapes:
    //   ['/admin','hudson-ingram','dashboard']  (trailing / or not)
    //   ['/admin','hudson-ingram','dashboard','index.html']
    //   ['/hudson-ingram','dashboard']          (if served without /admin)
    if (parts[0] === 'admin') return parts[1] || 'unknown';
    return parts[0] || 'unknown';
  }

  const artist = getArtistFromPath();
  const base   = `/api/${artist}`;
  console.debug('[Dashboard‑admin] artist =', artist);
  console.debug('[Dashboard‑admin] base API path =', base);

  const ep = {
    tasks   : `${base}/tasks`,
    comments: `${base}/comments`,
    audio   : `${base}/audio-files`,
    images  : `${base}/image-files`,
    events  : `${base}/calendar-events`
  };

  async function fetchAndRender (key) {
    const url  = ep[key];
    const list = document.getElementById(`${key}-list`);
    console.debug(`[Dashboard‑admin] fetching ${key} →`, url);

    try {
      const res  = await fetch(url);
      console.debug(`[Dashboard‑admin] ${key} status:`, res.status);
      if (!res.ok) throw new Error(res.statusText||res.status);
      const data = await res.json();
      list.innerHTML = '';
      data.forEach(item => {
        switch (key) {
          case 'tasks'   : list.insertAdjacentHTML('beforeend', `<li>${item.title} @ ${item.date.slice(0,10)}</li>`); break;
          case 'comments': list.insertAdjacentHTML('beforeend', `<li><b>${item.author||'anon'}:</b> ${item.text}</li>`); break;
          case 'audio'   : list.insertAdjacentHTML('beforeend', `<li><audio controls src="/uploads/audio/${item}"></audio></li>`); break;
          case 'images'  : list.insertAdjacentHTML('beforeend', `<li><img src="/uploads/images/${item}" alt=""></li>`); break;
          case 'events'  : list.insertAdjacentHTML('beforeend', `<li>${item.summary} — ${item.start.slice(0,10)}</li>`); break;
        }
      });
    } catch (err) {
      console.error(`[Dashboard‑admin] Error loading ${key}`, err);
      list.innerHTML = '<li style="color:#c00"><strong>Failed to load</strong></li>';
    }
  }

  /* kick‑off */
  ['tasks','comments','audio','images','events'].forEach(fetchAndRender);
  console.debug('[Dashboard‑admin] ready ✅');
})();
